This folder contains all tutorials that are available. Each tutorial should have its
own folder. The name of the folder is listed in the dropdown menu. Better make it start
with "X - " with X a digit, to get the correct ordering and Alt-keys.

Make sure all tutorials fit in the panel that is 220 pixels wide. Best use the same style file.

The tutorial must consist of pages page01.html, page02.html, etc. 

The tutorial "1 - Your First Game" must always remain present!